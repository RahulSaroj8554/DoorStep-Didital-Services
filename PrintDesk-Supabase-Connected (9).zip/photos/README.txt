Put your photos in this folder and reference them with relative paths, e.g. photos/shop.jpg
