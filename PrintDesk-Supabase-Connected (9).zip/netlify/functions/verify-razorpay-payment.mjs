import crypto from 'node:crypto';
export default async (req) => {
  if (req.method !== 'POST') return new Response('Method not allowed', { status: 405 });
  try {
    const { razorpay_order_id, razorpay_payment_id, razorpay_signature, order_id } = await req.json();
    const key = process.env.RAZORPAY_KEY_ID, secret = process.env.RAZORPAY_KEY_SECRET;
    const base = process.env.SUPABASE_URL, service = process.env.SUPABASE_SERVICE_ROLE_KEY;
    if (!key || !secret || !base || !service) return Response.json({ error: 'Payment verification is not configured.' }, { status: 503 });
    if (!/^[0-9a-f-]{36}$/i.test(String(order_id || ''))) return Response.json({ error: 'Invalid PrintDesk order.' }, { status: 400 });

    // Fetch the server-side order and Razorpay order to bind the payment to this exact amount/receipt.
    const dbRes = await fetch(`${base}/rest/v1/orders?id=eq.${encodeURIComponent(order_id)}&select=id,order_number,total_amount,payment_status`, { headers: { apikey: service, Authorization: `Bearer ${service}` } });
    const dbRows = await dbRes.json();
    const dbOrder = Array.isArray(dbRows) ? dbRows[0] : null;
    if (!dbRes.ok || !dbOrder) return Response.json({ error: 'PrintDesk order was not found.' }, { status: 404 });
    const auth = Buffer.from(`${key}:${secret}`).toString('base64');
    const rpRes = await fetch(`https://api.razorpay.com/v1/orders/${encodeURIComponent(razorpay_order_id)}`, { headers: { Authorization: `Basic ${auth}` } });
    const rpOrder = await rpRes.json();
    if (!rpRes.ok || rpOrder.receipt !== dbOrder.order_number || rpOrder.amount !== dbOrder.total_amount * 100 || rpOrder.currency !== 'INR') {
      return Response.json({ error: 'Payment does not match this PrintDesk order.' }, { status: 400 });
    }
    const expected = crypto.createHmac('sha256', secret).update(`${razorpay_order_id}|${razorpay_payment_id}`).digest('hex');
    const a = Buffer.from(expected), b = Buffer.from(String(razorpay_signature || ''));
    if (a.length !== b.length || !crypto.timingSafeEqual(a, b)) return Response.json({ error: 'Payment signature did not match.' }, { status: 400 });
    const r = await fetch(`${base}/rest/v1/orders?id=eq.${encodeURIComponent(order_id)}`, { method: 'PATCH', headers: { apikey: service, Authorization: `Bearer ${service}`, 'Content-Type': 'application/json', Prefer: 'return=minimal' }, body: JSON.stringify({ payment_status: 'paid', payment_reference: razorpay_payment_id }) });
    if (!r.ok) return Response.json({ error: 'Could not update order payment status.' }, { status: 502 });
    return Response.json({ verified: true });
  } catch { return Response.json({ error: 'Payment verification failed.' }, { status: 500 }); }
};
