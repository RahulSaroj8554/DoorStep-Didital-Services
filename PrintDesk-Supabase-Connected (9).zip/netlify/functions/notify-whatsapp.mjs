export default async (req) => {
  if (req.method !== 'POST') return new Response('Method not allowed', { status: 405 });
  const token = process.env.WHATSAPP_TOKEN, phoneId = process.env.WHATSAPP_PHONE_NUMBER_ID, to = process.env.SHOP_WHATSAPP_NUMBER;
  if (!token || !phoneId || !to) return Response.json({ sent: false, configured: false });
  try {
    const { order_number, customer_name, customer_phone, total_amount, fulfillment, payment_method } = await req.json();
    const body = `New PrintDesk order #${order_number}\n${customer_name} (${customer_phone})\nTotal: Rs ${total_amount}\n${fulfillment}\nPayment: ${payment_method}`;
    const r = await fetch(`https://graph.facebook.com/v21.0/${phoneId}/messages`, { method: 'POST', headers: { Authorization: `Bearer ${token}`, 'Content-Type': 'application/json' }, body: JSON.stringify({ messaging_product: 'whatsapp', recipient_type: 'individual', to, type: 'text', text: { body } }) });
    const data = await r.json();
    return Response.json({ sent: r.ok, configured: true, error: r.ok ? undefined : data.error?.message }, { status: r.ok ? 200 : 502 });
  } catch { return Response.json({ sent: false, configured: true }, { status: 500 }); }
};
