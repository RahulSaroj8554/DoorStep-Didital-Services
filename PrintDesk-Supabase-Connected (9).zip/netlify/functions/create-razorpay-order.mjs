export default async (req) => {
  if (req.method !== 'POST') return new Response('Method not allowed', { status: 405 });
  const key = process.env.RAZORPAY_KEY_ID, secret = process.env.RAZORPAY_KEY_SECRET;
  if (!key || !secret) return Response.json({ error: 'Online payment is not configured yet. Please choose cash or contact the shop.' }, { status: 503 });
  try {
    const { amount, receipt } = await req.json();
    if (!Number.isInteger(amount) || amount < 100 || amount > 5000000) return Response.json({ error: 'Invalid payment amount.' }, { status: 400 });
    const auth = Buffer.from(`${key}:${secret}`).toString('base64');
    const r = await fetch('https://api.razorpay.com/v1/orders', { method: 'POST', headers: { Authorization: `Basic ${auth}`, 'Content-Type': 'application/json' }, body: JSON.stringify({ amount, currency: 'INR', receipt: String(receipt || '').slice(0, 40) }) });
    const data = await r.json();
    if (!r.ok) return Response.json({ error: data.error?.description || 'Could not create payment.' }, { status: 502 });
    return Response.json({ id: data.id, amount: data.amount, currency: data.currency, keyId: key });
  } catch { return Response.json({ error: 'Payment service unavailable.' }, { status: 500 }); }
};
